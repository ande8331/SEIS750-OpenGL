Controls:

d = (Default) COlor Map
s = Specular Map
a = All Features Map
c = Toggles Clouds


Textures are the default textures specified for the assignment.  The Following texture files are expected within the "\images" folder:

Earth.png
earthcloudmap.png
EarthNight.png
EarthSpec.png